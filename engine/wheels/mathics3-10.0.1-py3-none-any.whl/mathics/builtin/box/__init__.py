r"""Expression Boxing

Boxes are central to <url>:Form processing:/doc/reference-of-built-in-symbols/forms-of-input-and-output/</url> \
of \Mathics expressions.

Boxing information, like the class of expression to be worked on and \
its size, allow formatters, like <url>:StandardForm:
/doc/reference-of-built-in-symbols/forms-of-input-and-output/general-purpose-forms/standardform/</url> \
to do their work without \
having to know more specific details and intricacies of expression to be formatted.

"""

# This tells documentation how to sort this module
sort_order = "mathics.builtin.expression-boxing"
